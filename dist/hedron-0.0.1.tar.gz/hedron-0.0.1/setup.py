from setuptools import setup

setup(name='hedron',
      version='0.0.1',
      description='A python package project for doing analysis on coordinates and clustering them.',
      author='Odos Matthews',
      author_email='odosmatthews@gmail.com',
      packages=['hedron'],
      intall_requires=['pandas'])